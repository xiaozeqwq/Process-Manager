package com.xiaoze_qwq_.mis;

import com.xiaoze_qwq_.mis.command.MISCommand;
import com.xiaoze_qwq_.mis.network.*;
import net.minecraft.server.MinecraftServer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(MCCInServer.MOD_ID)
public class MCCInServer {
    public static final String MOD_ID = "mccinserver";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static MinecraftServer serverInstance;

    public MCCInServer(IEventBus modEventBus) {
        modEventBus.addListener(this::registerPayloads);
        modEventBus.addListener(MISNetwork::commonSetup);
        NeoForge.EVENT_BUS.register(this);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        MISNetwork.register(event);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        MISCommand.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        serverInstance = event.getServer();
        LOGGER.info("MCC In Server started. LuckPerms not used, password-only mode.");
        MCCManager.getInstance().start();
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        MCCManager.getInstance().stop();
    }

    @SubscribeEvent
    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player) {
            MISSessionManager.getInstance().removePlayer(player.getUUID());
            MCCManager.getInstance().removeDisconnectedPlayer(player.getUUID());
        }
    }

    public static MinecraftServer getServer() {
        return serverInstance;
    }
}