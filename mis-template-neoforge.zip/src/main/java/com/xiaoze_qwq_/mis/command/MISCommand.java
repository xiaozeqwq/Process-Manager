package com.xiaoze_qwq_.mis.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.xiaoze_qwq_.mis.*;
import com.xiaoze_qwq_.mis.config.MISConfig;
import com.xiaoze_qwq_.mis.network.OpenStatusScreenPacket;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.concurrent.CompletableFuture;

public class MISCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        var base = Commands.literal("mis")
                .requires(src -> src.hasPermission(0) && !isCommandBlock(src));

        base.then(Commands.literal("verify")
                .then(Commands.argument("password", StringArgumentType.word())
                        .executes(MISCommand::executeVerify)));

        base.then(Commands.literal("reload").executes(MISCommand::executeReload));

        var instanceNode = Commands.argument("instance", StringArgumentType.word())
                .suggests((ctx, builder) -> {
                    for (MCCInstance inst : MCCManager.getInstance().getAllInstances()) {
                        builder.suggest(inst.getId());
                        builder.suggest(inst.getConfig().name);
                    }
                    return builder.buildFuture();
                })
                .executes(ctx -> executeInstanceHelp(ctx, getInstanceId(ctx)))
                .then(Commands.literal("input")
                        .then(Commands.argument("command", StringArgumentType.greedyString())
                                .executes(ctx -> executeInput(ctx, getInstanceId(ctx)))))
                .then(Commands.literal("start").executes(ctx -> executeStart(ctx, getInstanceId(ctx))))
                .then(Commands.literal("stop").executes(ctx -> executeStop(ctx, getInstanceId(ctx))))
                .then(Commands.literal("restart").executes(ctx -> executeRestart(ctx, getInstanceId(ctx))))
                .then(Commands.literal("forcestop").executes(ctx -> executeForceStop(ctx, getInstanceId(ctx))))
                .then(Commands.literal("status").executes(ctx -> executeStatus(ctx, getInstanceId(ctx))))
                .then(Commands.literal("immersive")
                        .then(Commands.literal("on").executes(ctx -> executeImmersiveOn(ctx, getInstanceId(ctx))))
                        .then(Commands.literal("off").executes(ctx -> executeImmersiveOff(ctx, getInstanceId(ctx)))))
                .then(Commands.literal("set")
                        .then(Commands.literal("history")
                                .then(Commands.argument("lines", IntegerArgumentType.integer(1, 10000))
                                        .executes(ctx -> {
                                            int lines = IntegerArgumentType.getInteger(ctx, "lines");
                                            String id = getInstanceId(ctx);
                                            MISConfig.setInstanceField(id, "historyLimit", lines);
                                            MCCInstance inst = MCCManager.getInstance().getInstance(id);
                                            if (inst != null) {
                                                inst.getConfig().historyLimit = lines;
                                                inst.resizeBuffer(lines);
                                            }
                                            ctx.getSource().sendSuccess(() -> Component.literal("History limit set to " + lines), false);
                                            return 1;
                                        })))
                        .then(Commands.literal("exitcode")
                                .then(Commands.argument("code", IntegerArgumentType.integer(0, 255))
                                        .executes(ctx -> {
                                            int code = IntegerArgumentType.getInteger(ctx, "code");
                                            String id = getInstanceId(ctx);
                                            MISConfig.setInstanceField(id, "exitCode", code);
                                            ctx.getSource().sendSuccess(() -> Component.literal("Exit code set to " + code + " (requires restart)"), false);
                                            return 1;
                                        })))
                        .then(Commands.literal("autorestart")
                                .then(Commands.literal("enable").executes(ctx -> {
                                    String id = getInstanceId(ctx);
                                    MISConfig.setInstanceField(id, "autoRestart", true);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Auto-restart enabled"), false);
                                    return 1;
                                }))
                                .then(Commands.literal("disable").executes(ctx -> {
                                    String id = getInstanceId(ctx);
                                    MISConfig.setInstanceField(id, "autoRestart", false);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Auto-restart disabled"), false);
                                    return 1;
                                })))
                        .then(Commands.literal("help").executes(ctx -> {
                            ctx.getSource().sendSuccess(() -> Component.translatable("mis.set.help.title"), false);
                            return 1;
                        })));

        base.then(instanceNode);
        base.executes(MISCommand::executeHelp);
        dispatcher.register(base);
    }

    private static boolean isCommandBlock(CommandSourceStack src) {
        return src.source instanceof net.minecraft.world.level.BaseCommandBlock;
    }

    private static String getInstanceId(CommandContext<CommandSourceStack> ctx) {
        String input = StringArgumentType.getString(ctx, "instance");
        // 尝试解析为数字，如果不是则按名称查找
        try {
            Integer.parseInt(input);
            return input;
        } catch (NumberFormatException e) {
            MCCInstance inst = MCCManager.getInstance().getInstanceByName(input);
            if (inst != null) {
                return inst.getId();
            }
            return input; // 返回原始输入，后续找不到实例时会报错
        }
    }

    private static boolean isConsole(CommandSourceStack src) { return src.getEntity() == null; }

    private static boolean checkPermission(CommandSourceStack src, String perm) throws CommandSyntaxException {
        if (isConsole(src)) return true;
        ServerPlayer player = src.getPlayer();
        if (player == null) return false;
        return MISSessionManager.getInstance().isInMISMode(player);
    }

    private static int executeVerify(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        var src = ctx.getSource();
        if (isConsole(src)) {
            src.sendSuccess(() -> Component.translatable("mis.verify.console_info"), false);
            return 1;
        }
        ServerPlayer player = src.getPlayer();
        if (!MISConfig.hasPassword()) {
            src.sendFailure(Component.translatable("mis.error.no_password"));
            return 0;
        }
        String pwd = StringArgumentType.getString(ctx, "password");
        if (MISConfig.getPassword().equals(pwd)) {
            MISSessionManager.getInstance().enterMISMode(player);
            src.sendSuccess(() -> Component.translatable("mis.verify.success"), false);
        } else {
            src.sendFailure(Component.translatable("mis.error.wrong_password"));
        }
        return 1;
    }

    private static int executeReload(CommandContext<CommandSourceStack> ctx) {
        MCCManager.getInstance().reloadInstances();
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.reload.success"), false);
        return 1;
    }

    private static int executeInput(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        if (!checkPermission(ctx.getSource(), "mis.mismode")) return errorNoPermission(ctx);
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (!inst.isRunning()) {
            ctx.getSource().sendFailure(Component.translatable("mis.error.mcc_not_running"));
            return 0;
        }
        String cmd = StringArgumentType.getString(ctx, "command");
        inst.sendCommand(cmd);
        return 1;
    }

    private static int executeStart(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        if (!checkPermission(ctx.getSource(), "mis.start")) return errorNoPermission(ctx);
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (inst.isRunning()) {
            ctx.getSource().sendFailure(Component.translatable("mis.error.already_running"));
            return 0;
        }
        if (!inst.canStartNewOperation()) {
            warnOtherOperation(ctx, inst);
            return 0;
        }
        CompletableFuture.runAsync(inst::start);
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.start.success"), false);
        return 1;
    }

    private static int executeStop(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        if (!checkPermission(ctx.getSource(), "mis.stop")) return errorNoPermission(ctx);
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (!inst.isRunning()) {
            ctx.getSource().sendFailure(Component.translatable("mis.error.not_running"));
            return 0;
        }
        if (!inst.canStartNewOperation()) {
            warnOtherOperation(ctx, inst);
            return 0;
        }
        CompletableFuture.runAsync(() -> inst.stop(true));
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.stop.success"), false);
        return 1;
    }

    private static int executeRestart(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        if (!checkPermission(ctx.getSource(), "mis.restart")) return errorNoPermission(ctx);
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (!inst.canStartNewOperation()) {
            warnOtherOperation(ctx, inst);
            return 0;
        }
        inst.restart();
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.restart.success"), false);
        return 1;
    }

    private static int executeForceStop(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        if (!checkPermission(ctx.getSource(), "mis.forcestop")) return errorNoPermission(ctx);
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (!inst.canStartNewOperation()) {
            warnOtherOperation(ctx, inst);
            return 0;
        }
        CompletableFuture.runAsync(() -> inst.forceStop());
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.forcestop.success"), false);
        return 1;
    }

    private static int executeStatus(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        var src = ctx.getSource();
        var player = src.getPlayer();
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (player == null) {
            String status = inst.getStatusMonitor() != null ? inst.getStatusMonitor().getFormattedStatus() : "Monitor not available.";
            src.sendSuccess(() -> Component.literal(status), false);
        } else {
            if (!checkPermission(src, "mis.status")) return errorNoPermission(ctx);
            PacketDistributor.sendToPlayer(player, new OpenStatusScreenPacket(id));
        }
        return 1;
    }

    private static int executeImmersiveOn(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        var src = ctx.getSource();
        var player = src.getPlayer();
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (player == null) {
            if (inst.isImmersiveConsole()) {
                src.sendFailure(Component.translatable("mis.immersive.already_on"));
                return 0;
            }
            inst.setImmersiveConsole(true);
            src.sendSuccess(() -> Component.translatable("mis.immersive.on"), false);
        } else {
            if (!checkPermission(src, "mis.immersive.read")) return errorNoPermission(ctx);
            boolean canInput = checkPermission(src, "mis.immersive.input");
            inst.addImmersiveSubscriber(player, canInput);
            src.sendSuccess(() -> Component.translatable("mis.immersive.on_player"), false);
        }
        return 1;
    }

    private static int executeImmersiveOff(CommandContext<CommandSourceStack> ctx, String id) throws CommandSyntaxException {
        var src = ctx.getSource();
        var player = src.getPlayer();
        MCCInstance inst = resolveInstance(ctx, id);
        if (inst == null) return 0;
        if (player == null) {
            if (!inst.isImmersiveConsole()) {
                src.sendFailure(Component.translatable("mis.immersive.already_off"));
                return 0;
            }
            inst.setImmersiveConsole(false);
            src.sendSuccess(() -> Component.translatable("mis.immersive.off"), false);
        } else {
            inst.removeImmersiveSubscriber(player);
        }
        return 1;
    }

    private static int executeInstanceHelp(CommandContext<CommandSourceStack> ctx, String id) {
        ctx.getSource().sendSuccess(() -> Component.literal("Commands for instance " + id + ": input/start/stop/restart/forcestop/status/immersive/set"), false);
        return 1;
    }

    private static int executeHelp(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendSuccess(() -> Component.translatable("mis.help.title"), false);
        return 1;
    }

    // 辅助方法：解析实例ID，如果不是数字则按名称查找，找不到发送错误
    private static MCCInstance resolveInstance(CommandContext<CommandSourceStack> ctx, String id) {
        MCCInstance inst;
        try {
            Integer.parseInt(id);
            inst = MCCManager.getInstance().getInstance(id);
        } catch (NumberFormatException e) {
            inst = MCCManager.getInstance().getInstanceByName(id);
        }
        if (inst == null) {
            ctx.getSource().sendFailure(Component.translatable("mis.error.instance_not_found", id));
        }
        return inst;
    }

    // 当有其他操作进行时，发送警告
    private static void warnOtherOperation(CommandContext<CommandSourceStack> ctx, MCCInstance inst) {
        ctx.getSource().sendFailure(Component.translatable("mis.error.other_operation", inst.getId()));
    }

    private static int errorNoPermission(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendFailure(Component.translatable("mis.error.not_in_mis_mode"));
        return 0;
    }
}