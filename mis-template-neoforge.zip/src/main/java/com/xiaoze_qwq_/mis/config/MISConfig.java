package com.xiaoze_qwq_.mis.config;

import com.moandjiezana.toml.Toml;
import com.xiaoze_qwq_.mis.MCCInServer;
import net.neoforged.fml.loading.FMLPaths;

import javax.crypto.Cipher;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class MISConfig {
    private static final Path CONFIG_PATH = FMLPaths.CONFIGDIR.get().resolve("mis_config.toml");
    private static final Path PRIVATE_KEY_PATH = FMLPaths.CONFIGDIR.get().resolve("mis_private_key.pem");
    private static final Path PUBLIC_KEY_PATH = FMLPaths.CONFIGDIR.get().resolve("mis_public_key.pem");
    private static final Path PASSWORD_FILE = Paths.get("mispassword");

    private static GlobalConfig global;
    private static InstanceConfig defaultConfig;
    private static Map<String, InstanceConfig> instances = new ConcurrentHashMap<>();

    private static PrivateKey privateKey;
    private static PublicKey publicKey;

    static {
        loadKeys();
        load();
    }

    // ==================== 密钥管理 ====================
    private static void loadKeys() {
        try {
            if (Files.exists(PRIVATE_KEY_PATH) && Files.exists(PUBLIC_KEY_PATH)) {
                privateKey = loadPrivateKey(Files.readAllBytes(PRIVATE_KEY_PATH));
                publicKey = loadPublicKey(Files.readAllBytes(PUBLIC_KEY_PATH));
            } else {
                generateKeyPair();
            }
        } catch (Exception e) {
            MCCInServer.LOGGER.error("Failed to load RSA keys, generating new pair", e);
            generateKeyPair();
        }
    }

    private static void generateKeyPair() {
        try {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            KeyPair pair = gen.generateKeyPair();
            privateKey = pair.getPrivate();
            publicKey = pair.getPublic();
            Files.write(PRIVATE_KEY_PATH, privateKey.getEncoded());
            Files.write(PUBLIC_KEY_PATH, publicKey.getEncoded());
            MCCInServer.LOGGER.info("Generated new RSA key pair.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate RSA keys", e);
        }
    }

    private static PrivateKey loadPrivateKey(byte[] keyBytes) throws Exception {
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        return factory.generatePrivate(spec);
    }

    private static PublicKey loadPublicKey(byte[] keyBytes) throws Exception {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        return factory.generatePublic(spec);
    }

    private static String encryptPassword(String plain) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    private static String decryptPassword(String encryptedBase64) throws Exception {
        byte[] encrypted = Base64.getDecoder().decode(encryptedBase64);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decrypted = cipher.doFinal(encrypted);
        return new String(decrypted, StandardCharsets.UTF_8);
    }

    // ==================== 配置数据类 ====================
    public static class GlobalConfig {
        public String password = "";
    }

    public static class InstanceConfig {
        public String id;
        public String name = "";
        public boolean autoStart = false;
        public int startupDelaySeconds = 0;
        public String workingDirectory = "";
        public String executablePath = "MCC/MinecraftClient";
        public List<String> arguments = new ArrayList<>();
        public Map<String, String> environment = new HashMap<>();

        public boolean autoRestart = true;
        public int exitCode = 0;
        public int statusRefreshSeconds = 2;
        public boolean enableProcessMonitor = true;
        public boolean enableNetworkMonitor = true;
        public int historyLimit = 2000;
        public String logDirectory = "MCC-Output";
        public String compressionFormat = "tar.gz";
        public String compressionStrategy = "OLD";
        public int scheduledCompressionMinutes = 60;
        public int maxArchives = 10;
        public boolean saveLogTime = true;
        public String timeFormat = "HH:mm:ss";
        public boolean outputAlone = false;
        public boolean outputWithTime = true;
        public String outputTimeFormat = "HH:mm:ss";

        public void mergeMissing(InstanceConfig defaults) {
            if (name.isEmpty() && defaults != null) name = defaults.name;
            if (executablePath == null || executablePath.isEmpty()) executablePath = defaults.executablePath;
            if (arguments.isEmpty()) arguments = defaults.arguments;
            if (environment.isEmpty()) environment = defaults.environment;
            if (workingDirectory.isEmpty()) workingDirectory = defaults.workingDirectory;
            if (logDirectory.isEmpty()) logDirectory = defaults.logDirectory;
            if (statusRefreshSeconds <= 0) statusRefreshSeconds = defaults.statusRefreshSeconds;
            if (historyLimit <= 0) historyLimit = defaults.historyLimit;
            if (exitCode < 0) exitCode = defaults.exitCode;
            if (maxArchives <= 0) maxArchives = defaults.maxArchives;
        }
    }

    // ==================== 加载与保存 ====================
    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            global = new GlobalConfig();
            defaultConfig = new InstanceConfig();
            instances.clear();
            InstanceConfig defInst = new InstanceConfig();
            defInst.id = "1";
            defInst.name = "MCC-1";
            instances.put("1", defInst);
            saveToml();
            migratePassword();
            return;
        }

        try (Reader reader = new InputStreamReader(Files.newInputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
            Toml toml = new Toml().read(reader);

            global = new GlobalConfig();
            global.password = toml.getString("global.password", "");

            defaultConfig = parseInstanceConfig(toml.getTable("default"), "default");

            instances.clear();
            List<Toml> instanceTables = toml.getTables("instances");
            if (instanceTables != null) {
                for (Toml instToml : instanceTables) {
                    String id = instToml.getString("id", "");
                    if (id.isEmpty()) continue;
                    InstanceConfig cfg = parseInstanceConfig(instToml, id);
                    cfg.id = id;
                    mergeWithDefault(cfg);
                    instances.put(id, cfg);
                }
            }
            if (instances.isEmpty()) {
                InstanceConfig defInst = new InstanceConfig();
                defInst.id = "1";
                defInst.name = "MCC-1";
                mergeWithDefault(defInst);
                instances.put("1", defInst);
            }

            // ==================== 实例校验 ====================
            Iterator<Map.Entry<String, InstanceConfig>> it = instances.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, InstanceConfig> entry = it.next();
                String id = entry.getKey();
                InstanceConfig cfg = entry.getValue();

                // ID 必须为纯数字
                if (!id.matches("\\d+")) {
                    MCCInServer.LOGGER.error("Instance ID '{}' is not a pure number. Skipping instance.", id);
                    it.remove();
                    continue;
                }

                // 名称不能是纯数字
                if (cfg.name != null && cfg.name.matches("\\d+")) {
                    MCCInServer.LOGGER.error("Instance '{}' has a numeric name '{}'. Please use a non-numeric name.", id, cfg.name);
                    it.remove();
                    continue;
                }

                // 检查名称是否重复（不区分大小写）
                String lowerName = (cfg.name != null ? cfg.name : "").toLowerCase(Locale.ROOT);
                for (Map.Entry<String, InstanceConfig> other : instances.entrySet()) {
                    if (other.getKey().equals(id)) continue;
                    String otherLower = (other.getValue().name != null ? other.getValue().name : "").toLowerCase(Locale.ROOT);
                    if (lowerName.equals(otherLower)) {
                        MCCInServer.LOGGER.error("Duplicate instance name '{}' (case-insensitive) between instances '{}' and '{}'. Skipping instance '{}'.",
                                cfg.name, id, other.getKey(), id);
                        it.remove();
                        break;
                    }
                }
            }

            saveToml();
            migratePassword();
        } catch (Exception e) {
            MCCInServer.LOGGER.error("Failed to load mis_config.toml, using defaults", e);
            global = new GlobalConfig();
            defaultConfig = new InstanceConfig();
            instances.clear();
            InstanceConfig defInst = new InstanceConfig();
            defInst.id = "1";
            defInst.name = "MCC-1";
            instances.put("1", defInst);
        }
    }

    private static InstanceConfig parseInstanceConfig(Toml table, String fallbackId) {
        InstanceConfig cfg = new InstanceConfig();
        if (table == null) return cfg;
        cfg.id = table.getString("id", fallbackId);
        cfg.name = table.getString("name", "");
        cfg.autoStart = table.getBoolean("autoStart", false);
        cfg.startupDelaySeconds = table.getLong("startupDelaySeconds", 0L).intValue();
        cfg.workingDirectory = table.getString("workingDirectory", "");
        cfg.executablePath = table.getString("executablePath", "MCC/MinecraftClient");
        cfg.arguments = table.getList("arguments", new ArrayList<>());
        cfg.environment = table.getTable("environment") != null ? toStringMap(table.getTable("environment")) : new HashMap<>();
        cfg.autoRestart = table.getBoolean("autoRestart", true);
        cfg.exitCode = table.getLong("exitCode", 0L).intValue();
        cfg.statusRefreshSeconds = table.getLong("statusRefreshSeconds", 2L).intValue();
        cfg.enableProcessMonitor = table.getBoolean("enableProcessMonitor", true);
        cfg.enableNetworkMonitor = table.getBoolean("enableNetworkMonitor", true);
        cfg.historyLimit = table.getLong("historyLimit", 2000L).intValue();
        cfg.logDirectory = table.getString("logDirectory", "");
        cfg.compressionFormat = table.getString("compressionFormat", "tar.gz");
        cfg.compressionStrategy = table.getString("compressionStrategy", "OLD");
        cfg.scheduledCompressionMinutes = table.getLong("scheduledCompressionMinutes", 60L).intValue();
        cfg.maxArchives = table.getLong("maxArchives", 10L).intValue();
        cfg.saveLogTime = table.getBoolean("saveLogTime", true);
        cfg.timeFormat = table.getString("timeFormat", "HH:mm:ss");
        cfg.outputAlone = table.getBoolean("outputAlone", false);
        cfg.outputWithTime = table.getBoolean("outputWithTime", true);
        cfg.outputTimeFormat = table.getString("outputTimeFormat", "HH:mm:ss");
        return cfg;
    }

    private static void mergeWithDefault(InstanceConfig cfg) {
        if (cfg.name == null || cfg.name.isEmpty()) cfg.name = defaultConfig.name.isEmpty() ? cfg.id : defaultConfig.name;
        if (cfg.executablePath == null || cfg.executablePath.isEmpty()) cfg.executablePath = defaultConfig.executablePath;
        if (cfg.arguments.isEmpty() && !defaultConfig.arguments.isEmpty()) cfg.arguments = defaultConfig.arguments;
        if (cfg.environment.isEmpty() && !defaultConfig.environment.isEmpty()) cfg.environment = defaultConfig.environment;
        if (cfg.workingDirectory.isEmpty()) cfg.workingDirectory = defaultConfig.workingDirectory;
        if (cfg.logDirectory.isEmpty()) cfg.logDirectory = defaultConfig.logDirectory.isEmpty() ? "MCC-Output" : defaultConfig.logDirectory;
        if (cfg.statusRefreshSeconds <= 0) cfg.statusRefreshSeconds = defaultConfig.statusRefreshSeconds;
        if (cfg.historyLimit <= 0) cfg.historyLimit = defaultConfig.historyLimit;
        if (cfg.exitCode < 0) cfg.exitCode = defaultConfig.exitCode;
        if (cfg.maxArchives <= 0) cfg.maxArchives = defaultConfig.maxArchives;
    }

    private static Map<String, String> toStringMap(Toml table) {
        Map<String, String> map = new HashMap<>();
        table.toMap().forEach((k, v) -> map.put(k, v.toString()));
        return map;
    }

    private static void migratePassword() {
        if (global.password != null && !global.password.isEmpty()) {
            try {
                String encrypted = encryptPassword(global.password);
                Files.write(PASSWORD_FILE, encrypted.getBytes(StandardCharsets.UTF_8));
                global.password = "";
                saveToml();
                MCCInServer.LOGGER.info("Password encrypted and stored in mispassword.");
            } catch (Exception e) {
                MCCInServer.LOGGER.error("Failed to encrypt password, keeping plaintext in config", e);
            }
        } else if (Files.exists(PASSWORD_FILE)) {
            try {
                String encrypted = new String(Files.readAllBytes(PASSWORD_FILE), StandardCharsets.UTF_8).trim();
                String decrypted = decryptPassword(encrypted);
                if (decrypted != null) {
                    global.password = decrypted;
                }
            } catch (Exception e) {
                MCCInServer.LOGGER.error("Failed to decrypt password from mispassword, password will be empty", e);
                global.password = "";
            }
        }
    }

    private static void saveToml() {
        try (Writer writer = new OutputStreamWriter(Files.newOutputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
            writer.write("# MIS Configuration (TOML)\n\n");
            writer.write("[global]\n");
            writer.write("password = \"\"\n\n");
            writer.write("[default]\n");
            writeInstanceConfig(writer, defaultConfig, true);
            writer.write("\n");
            for (InstanceConfig cfg : instances.values()) {
                writer.write("[[instances]]\n");
                writer.write("id = \"" + cfg.id + "\"\n");
                writeInstanceConfig(writer, cfg, false);
                writer.write("\n");
            }
        } catch (IOException e) {
            MCCInServer.LOGGER.error("Failed to save mis_config.toml", e);
        }
    }

    private static void writeInstanceConfig(Writer writer, InstanceConfig cfg, boolean skipId) throws IOException {
        writer.write("name = \"" + cfg.name + "\"\n");
        writer.write("autoStart = " + cfg.autoStart + "\n");
        writer.write("startupDelaySeconds = " + cfg.startupDelaySeconds + "\n");
        writer.write("workingDirectory = \"" + cfg.workingDirectory + "\"\n");
        writer.write("executablePath = \"" + cfg.executablePath + "\"\n");
        writer.write("arguments = " + cfg.arguments.toString() + "\n");
        writer.write("environment = " + cfg.environment.toString() + "\n");
        writer.write("autoRestart = " + cfg.autoRestart + "\n");
        writer.write("exitCode = " + cfg.exitCode + "\n");
        writer.write("statusRefreshSeconds = " + cfg.statusRefreshSeconds + "\n");
        writer.write("enableProcessMonitor = " + cfg.enableProcessMonitor + "\n");
        writer.write("enableNetworkMonitor = " + cfg.enableNetworkMonitor + "\n");
        writer.write("historyLimit = " + cfg.historyLimit + "\n");
        writer.write("logDirectory = \"" + cfg.logDirectory + "\"\n");
        writer.write("compressionFormat = \"" + cfg.compressionFormat + "\"\n");
        writer.write("compressionStrategy = \"" + cfg.compressionStrategy + "\"\n");
        writer.write("scheduledCompressionMinutes = " + cfg.scheduledCompressionMinutes + "\n");
        writer.write("maxArchives = " + cfg.maxArchives + "\n");
        writer.write("saveLogTime = " + cfg.saveLogTime + "\n");
        writer.write("timeFormat = \"" + cfg.timeFormat + "\"\n");
        writer.write("outputAlone = " + cfg.outputAlone + "\n");
        writer.write("outputWithTime = " + cfg.outputWithTime + "\n");
        writer.write("outputTimeFormat = \"" + cfg.outputTimeFormat + "\"\n");
    }

    // ==================== 公共访问器 ====================
    public static String getPassword() { return global.password; }
    public static boolean hasPassword() { return global.password != null && !global.password.isEmpty(); }

    public static Collection<InstanceConfig> getAllInstances() { return instances.values(); }
    public static InstanceConfig getInstanceConfig(String id) { return instances.get(id); }
    public static String[] getInstanceIds() { return instances.keySet().toArray(new String[0]); }
    public static boolean instanceExists(String id) { return instances.containsKey(id); }

    public static void setPassword(String pw) { global.password = pw; saveToml(); }
    public static void setInstanceField(String id, String field, Object value) {
        InstanceConfig cfg = instances.get(id);
        if (cfg == null) return;
        switch (field) {
            case "autoRestart": cfg.autoRestart = (boolean) value; break;
            case "exitCode": cfg.exitCode = (int) value; break;
            case "statusRefreshSeconds": cfg.statusRefreshSeconds = (int) value; break;
            case "enableProcessMonitor": cfg.enableProcessMonitor = (boolean) value; break;
            case "enableNetworkMonitor": cfg.enableNetworkMonitor = (boolean) value; break;
            case "historyLimit": cfg.historyLimit = (int) value; break;
            case "logDirectory": cfg.logDirectory = (String) value; break;
            case "saveLogTime": cfg.saveLogTime = (boolean) value; break;
            case "timeFormat": cfg.timeFormat = (String) value; break;
            case "executablePath": cfg.executablePath = (String) value; break;
            case "outputAlone": cfg.outputAlone = (boolean) value; break;
            case "outputWithTime": cfg.outputWithTime = (boolean) value; break;
            case "outputTimeFormat": cfg.outputTimeFormat = (String) value; break;
        }
        saveToml();
    }
}