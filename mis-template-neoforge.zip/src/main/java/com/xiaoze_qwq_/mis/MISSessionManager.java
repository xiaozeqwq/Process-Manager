package com.xiaoze_qwq_.mis;

import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MISSessionManager {
    private static final MISSessionManager INSTANCE = new MISSessionManager();
    private final Map<UUID, Boolean> misModePlayers = new ConcurrentHashMap<>();

    private MISSessionManager() {}

    public static MISSessionManager getInstance() {
        return INSTANCE;
    }

    public void enterMISMode(ServerPlayer player) {
        misModePlayers.put(player.getUUID(), true);
    }

    public void exitMISMode(ServerPlayer player) {
        misModePlayers.remove(player.getUUID());
    }

    public boolean isInMISMode(ServerPlayer player) {
        return misModePlayers.getOrDefault(player.getUUID(), false);
    }

    public void removePlayer(UUID uuid) {
        misModePlayers.remove(uuid);
    }
}